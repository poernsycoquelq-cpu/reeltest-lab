plugins {
    id("com.android.application")
}

android {
    namespace = "com.reeltestlab.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.reeltestlab.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
