package com.reeltestlab.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;

import java.util.Locale;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private EditText titleInput, viewsInput, likesInput, commentsInput, sharesInput;
    private TextView summary;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("reeltest_data", MODE_PRIVATE);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(22));
        page.setBackgroundColor(0xFFF5F6FA);

        TextView heading = new TextView(this);
        heading.setText("REELTEST LAB");
        heading.setTextSize(26);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setTextColor(0xFF172554);
        page.addView(heading);

        TextView intro = new TextView(this);
        intro.setText("Registro manual de métricas públicas de tus videos y Reels. No genera visitas ni modifica estadísticas de Facebook.");
        intro.setTextSize(14);
        intro.setTextColor(0xFF475569);
        intro.setPadding(0, dp(8), 0, dp(18));
        page.addView(intro);

        titleInput = field("Nombre o enlace del Reel", false);
        viewsInput = field("Reproducciones / vistas", true);
        likesInput = field("Me gusta", true);
        commentsInput = field("Comentarios", true);
        sharesInput = field("Compartidos", true);

        page.addView(titleInput);
        page.addView(viewsInput);
        page.addView(likesInput);
        page.addView(commentsInput);
        page.addView(sharesInput);

        Button save = new Button(this);
        save.setText("GUARDAR REGISTRO");
        page.addView(save);
        save.setOnClickListener(v -> saveRecord());

        Button reset = new Button(this);
        reset.setText("BORRAR REGISTRO GUARDADO");
        page.addView(reset);
        reset.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            showSummary();
            Toast.makeText(this, "Registro eliminado", Toast.LENGTH_SHORT).show();
        });

        summary = new TextView(this);
        summary.setTextSize(15);
        summary.setTextColor(0xFF0F172A);
        summary.setPadding(0, dp(18), 0, 0);
        page.addView(summary);

        setContentView(page);
        showSummary();
    }

    private EditText field(String hint, boolean numeric) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint(hint);
        input.setTextSize(15);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF64748B));
        if (numeric) input.setInputType(InputType.TYPE_CLASS_NUMBER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(8);
        input.setLayoutParams(lp);
        return input;
    }

    private void saveRecord() {
        String title = titleInput.getText().toString().trim();
        if (title.isEmpty()) {
            titleInput.setError("Escribe el nombre o enlace del video");
            return;
        }
        long views = number(viewsInput), likes = number(likesInput);
        long comments = number(commentsInput), shares = number(sharesInput);
        prefs.edit()
            .putString("title", title)
            .putLong("views", views)
            .putLong("likes", likes)
            .putLong("comments", comments)
            .putLong("shares", shares)
            .apply();
        showSummary();
        Toast.makeText(this, "Métricas guardadas en este dispositivo", Toast.LENGTH_SHORT).show();
    }

    private long number(EditText input) {
        String value = input.getText().toString().trim();
        if (value.isEmpty()) return 0;
        try { return Long.parseLong(value); }
        catch (NumberFormatException ex) { return 0; }
    }

    private void showSummary() {
        if (summary == null) return;
        String title = prefs.getString("title", null);
        if (title == null) {
            summary.setText("Todavía no hay métricas guardadas.");
            return;
        }
        summary.setText(String.format(Locale.getDefault(),
            "ÚLTIMO REGISTRO\n%s\n\nReproducciones: %,d\nMe gusta: %,d\nComentarios: %,d\nCompartidos: %,d",
            title, prefs.getLong("views", 0), prefs.getLong("likes", 0),
            prefs.getLong("comments", 0), prefs.getLong("shares", 0)));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
