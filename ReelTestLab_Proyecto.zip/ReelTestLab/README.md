# ReelTest Lab

Aplicación Android inicial para registrar manualmente métricas observadas de videos y Reels.

## Alcance de esta primera versión
- Guarda localmente el nombre/enlace del video y las cifras de reproducciones, Me gusta, comentarios y compartidos.
- No inicia sesión en Facebook, no extrae datos privados, no automatiza reproducciones y no infla métricas.
- Los datos se guardan únicamente en el dispositivo.

## Versiones fijadas
- Android Gradle Plugin: 9.5.0
- Gradle en GitHub Actions: 9.6.0
- JDK: 17
- Android compileSdk / targetSdk: 36
- Lenguaje: Java 17
- minSdk: 23

## Compilación
El workflow `.github/workflows/main.yml` compila `app-debug.apk` y lo publica como artefacto de GitHub Actions.
