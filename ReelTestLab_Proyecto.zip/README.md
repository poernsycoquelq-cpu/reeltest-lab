# ReelTest Lab

Proyecto Android para registrar manualmente métricas observadas de videos y Reels.

## Estructura importante

Los archivos `settings.gradle.kts` y `build.gradle.kts` están en la raíz del proyecto. La carpeta `.github/workflows` contiene el flujo de GitHub Actions.

## Funciones de esta versión
- Registrar nombre o enlace de un Reel/video.
- Registrar manualmente reproducciones, Me gusta, comentarios y compartidos.
- Guardar el último registro localmente en el teléfono.

Esta aplicación no inicia sesión en Facebook, no extrae datos privados, no automatiza reproducciones y no genera ni infla visitas.

## Cómo subirlo a GitHub desde el celular
1. Descarga y extrae este ZIP.
2. Abre la carpeta extraída `ReelTestLab`.
3. Sube al repositorio el CONTENIDO de esa carpeta: `app`, `.github`, `gradle`, `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `.gitignore` y `README.md`.
4. No subas solamente el archivo ZIP.
5. No dejes todos los archivos dentro de una segunda carpeta `ReelTestLab` en GitHub. `settings.gradle.kts` debe verse en la página principal del repositorio.

## Compilación
GitHub Actions ejecuta el workflow `.github/workflows/main.yml`. Cuando termine correctamente, descarga el artefacto `ReelTestLab-debug-apk` desde la ejecución en la pestaña Actions.

## Versiones configuradas
- Android Gradle Plugin: 9.5.0
- Gradle: 9.6.0
- JDK: 17
- compileSdk / targetSdk: 36
- minSdk: 23
